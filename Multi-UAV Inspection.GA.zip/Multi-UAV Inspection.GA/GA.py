from itertools import product

from typing import List, Dict,Tuple
import random
import numpy as np
from copy import deepcopy
from typing import List, Dict
from scipy.spatial import KDTree
#最优解的解法！！！！！！！！！！！！！！！！！！！！！！！！#
def selection_operator(
        population: List,
        fitness: List[float],
        elite_ratio: float = 0.05,
        tournament_size: int = 3,
        tournament_winners: int = 2
) -> Tuple[List, List[float]]:
    """
    返回: (新种群, 新适应度列表)
    """
    population_size = len(population)
    elite_num = int(population_size * elite_ratio)

    # ========================
    # 1. 精英选择 (带适应度)
    # ========================
    # 按适应度排序（假设越小越好）
    sorted_pop = sorted(zip(population, fitness), key=lambda x: x[1])

    # 提取精英个体和适应度
    elite_pop = [x[0] for x in sorted_pop[:elite_num]]
    elite_fitness = [x[1] for x in sorted_pop[:elite_num]]

    # ========================
    # 2. 锦标赛选择 (带适应度跟踪)
    # ========================
    remaining_indices = list(range(elite_num, population_size))  # 非精英个体索引
    new_pop = elite_pop.copy()
    new_fitness = elite_fitness.copy()

    while len(new_pop) < population_size:
        # 随机抽取一组（允许重复参赛）
        group_indices = np.random.choice(remaining_indices, size=tournament_size, replace=True)

        # 获取组内个体和适应度
        group = [(population[i], fitness[i]) for i in group_indices]

        # 按适应度排序并选优
        group_sorted = sorted(group, key=lambda x: x[1])
        winners = group_sorted[:tournament_winners]

        # 添加到新种群
        for ind, fit in winners:
            if len(new_pop) < population_size:
                new_pop.append(ind)
                new_fitness.append(fit)

    # ========================
    # 3. 验证与返回
    # ========================
    assert len(new_pop) == len(new_fitness) == population_size
    return new_pop, new_fitness

#--------------------交叉阶段-------------------------#


def crossover(population: List[List[Dict]],
              max_step_distance: float = 3.0,
              verbose: bool = False) -> List[List[Dict]]:
    """
    改进版交叉操作：基于路径连续性的智能修复

    主要流程：
    1. 随机决定是否进行交叉
    2. 检测并移除不连续路径段
    3. 将移除的点重新插入到最佳位置

    参数:
        max_step_distance: 允许的最大两点间距离(与generate_population一致)
    """
    new_population = []

    for agent in population:
        # 深拷贝当前Agent
        new_agent = deepcopy(agent)

        # 随机决定是否交叉 (保留原概率)
        if random.random() > 0.8:
            new_population.append(new_agent)
            continue

        # ===== 1. 检测并移除不连续路径点 =====
        removed_points = []
        remaining_points = []

        for uav_idx in range(3):
            points = new_agent[uav_idx]['points']
            if len(points) < 2:
                remaining_points.append(points)
                continue

            # 计算相邻点距离
            distances = np.linalg.norm(np.diff(points, axis=0), axis=1)
            violation_indices = np.where(distances > max_step_distance)[0]

            if len(violation_indices) == 0:
                remaining_points.append(points)
                continue

            # 找到第一个违规点及其后续所有点
            first_violation = violation_indices[0]
            removed = points[first_violation + 1:].copy()
            kept = points[:first_violation + 1]

            removed_points.extend(removed)
            remaining_points.append(kept)
            new_agent[uav_idx]['points'] = kept

            if verbose:
                print(f"UAV {uav_idx} 移除 {len(removed)} 个点 | 首违规距离: {distances[first_violation]:.2f}m")

        # ===== 2. 重新分配被移除的点 =====
        if removed_points:
            # 构建所有剩余点的KDTree加速搜索
            all_remaining = np.vstack([p for p in remaining_points if len(p) > 0])
            if len(all_remaining) == 0:
                continue  # 极端情况处理

            kdtree = KDTree(all_remaining)

            for point in removed_points:
                # 查找最近邻
                dist, idx = kdtree.query(point)
                nearest_point = all_remaining[idx]

                # 确定所属无人机和插入位置
                for uav_idx in range(3):
                    if len(new_agent[uav_idx]['points']) == 0:
                        continue

                    # 检查该最近点是否属于当前无人机
                    if np.any(np.all(nearest_point == new_agent[uav_idx]['points'], axis=1)):
                        insert_pos = np.where(
                            np.all(new_agent[uav_idx]['points'] == nearest_point, axis=1)
                        )[0][0] + 1

                        # 执行插入
                        new_path = np.insert(
                            new_agent[uav_idx]['points'],
                            insert_pos,
                            point,
                            axis=0
                        )
                        new_agent[uav_idx]['points'] = new_path
                        break

            if verbose:
                print(f"已重新分配 {len(removed_points)} 个点 | 最大插入距离: {dist:.2f}m")

        new_population.append(new_agent)

    return new_population


#---------------------变异---------------------#

def mutation(population: List[List[Dict]],
             current_gen: int,
             max_generations: int,
             initial_mutation_rate: float = 0.5,  # 调低初始概率
             min_mutation_rate: float = 0.05,
             optimization_strength: float = 0.3,  # 新增强度控制参数
             verbose: bool = False) -> List[List[Dict]]:
    """
    带强度控制的温和变异算法
        population: 当前种群（每个agent包含3架无人机）
        current_gen: 当前代数
        max_generations: 总代数
        initial_mutation_rate: 初始变异概率
        min_mutation_rate: 最小变异概率
        verbose: 是否打印变异详情
    改进点：
    1. 概率性执行优化（非强制优化）
    2. 引入优化强度参数
    3. 自适应窗口大小
    """
    # ===== 1. 自适应参数 =====
    progress = current_gen / max_generations
    mutation_rate = initial_mutation_rate * (1 - progress ** 1.5)  # 更平缓的衰减
    mutation_rate = max(mutation_rate, min_mutation_rate)

    # 动态调整优化强度（前期强后期弱）
    current_strength = optimization_strength * (1 - progress)

    if verbose and random.random() < 0.05:
        print(f"\nGen {current_gen}: 变异率={mutation_rate:.2f} 强度={current_strength:.2f}")

    new_pop = []
    for agent in population:
        new_agent = []
        for uav in agent:
            mutated_uav = deepcopy(uav)

            # ===== 2. 概率性进入变异 =====
            if random.random() > mutation_rate or len(uav['points']) < 3:
                new_agent.append(mutated_uav)
                continue

            points = mutated_uav['points']

            # ===== 3. 带强度控制的优化 =====
            for i in range(len(points) - 2):
                # 按概率跳过部分优化机会
                if random.random() > current_strength:
                    continue

                A, B, C = points[i], points[i + 1], points[i + 2]
                original_dist = np.linalg.norm(A - B) + np.linalg.norm(B - C)
                swapped_dist = np.linalg.norm(A - C) + np.linalg.norm(C - B)

                # 引入优化阈值（避免微优化）
                if swapped_dist < original_dist * 0.98:  # 只有明显改善才执行
                    points[i + 1], points[i + 2] = C.copy(), B.copy()

                    if verbose and random.random() < 0.1:
                        print(f"优化 @ {i}: {original_dist:.2f}→{swapped_dist:.2f}")

            new_agent.append(mutated_uav)

        new_pop.append(new_agent)

    return new_pop



# 兼容保留的辅助函数（实际已不需要但保持接口一致）
def print_mutation_example(original: Dict, mutated: Dict, changed_indices: List[int]):
    """示例输出函数（保留接口）"""
    diff_mask = ~np.all(original['points'] == mutated['points'], axis=1)
    changed = np.where(diff_mask)[0]

    print(f"\n路径优化变异结果：")
    print(f"总修改点数量: {len(changed)}")
    if len(changed) > 0:
        sample = changed[0]
        print(f"示例修改 @ 点{sample}:")
        print(f"原路径: {original['points'][sample]} → {original['points'][sample + 1]}")
        print(f"新路径: {mutated['points'][sample]} → {mutated['points'][sample + 1]}")


'''

调试模组 

# 野生陆生海参
# EditTime:2025/4/21 18:56
import popInit
import pop2Track
import ObjectFunction
import numpy as np
import GA
import random
from typing import List, Dict, Tuple
import GATest
import GATest2

#演示用

if __name__ == "__main__":

    # 新的危险区定义格式：
    # ['x'/'y', 各轴最小/最大值] 分别对应X=0或Y=0平面
    danger_zones = [
        ['x', 5, 10, 5, 10],  # X=0平面上的危险区 (y_min, y_max, z_min, z_max)
        ['y', 5, 10, 5, 10],  # Y=0平面上的危险区 (x_min, x_max, z_min, z_max)
    ]

    # 平面参数设置 (现在可以接受零范围)
    x_plane_size = (0, 25, 0, 25)  # X=0平面: y_min, y_max, z_min, z_max
    y_plane_size = (0, 25, 0, 25)  # Y=0平面: x_min, x_max, z_min, z_max

    # 生成视点
    normal_points, danger_points = popInit.generate_viewpoints(
        danger_zones=danger_zones,
        normal_spacing=3,
        danger_spacing=1.75,
        x_plane_size=x_plane_size,
        y_plane_size=y_plane_size,
        z_range=(0, 5)  # 全局Z范围限制
    )

    # 生成种群 (100个代理，每个代理3架无人机)
    population = pop2Track.generate_population(normal_points, danger_points, num_agents=100, num_uavs=3)
    #这边可视化一遍
    population = GATest.crossover(population,10,True)
    #这边可视化一遍
    population = GATest2.mutation(population,30,100,0.7,0.1,True)
    # 可视化示例代理
    def visualize_agent(agent_trajectories, normal_pts, danger_pts):
        try:
            import matplotlib.pyplot as plt
            from mpl_toolkits.mplot3d import Axes3D

            fig = plt.figure(figsize=(14, 10))
            ax = fig.add_subplot(111, projection='3d')

            colors = ['red', 'green', 'blue']
            labels = ['UAV A', 'UAV B', 'UAV C']

            # 绘制原始点集
            ax.scatter(normal_pts[:, 0], normal_pts[:, 1], normal_pts[:, 2],
                       c='gray', alpha=0.2, s=15, label='All Normal Points')
            ax.scatter(danger_pts[:, 0], danger_pts[:, 1], danger_pts[:, 2],
                       c='orange', alpha=0.3, s=20, label='All Danger Points')

            # 绘制分配结果
            for i, uav in enumerate(agent_trajectories):
                pts = uav['points']
                if len(pts) > 0:
                    ax.scatter(pts[:, 0], pts[:, 1], pts[:, 2],
                               color=colors[i], s=50, label=labels[i])

                    # 按照轨迹顺序连线
                    ax.plot(pts[:, 0], pts[:, 1], pts[:, 2],
                            color=colors[i], linestyle=':', alpha=0.6, linewidth=1)

            ax.set_xlabel('X轴')
            ax.set_ylabel('Y轴')
            ax.set_zlabel('Z轴')
            plt.title('示例代理的无人机轨迹分配 (3架无人机)')
            plt.legend()
            plt.tight_layout()
            plt.show()
        except ImportError:
            print("Matplotlib未安装，跳过可视化")


    # 可视化前3个代理
    for i in range(3):
        print(f"\n可视化代理 {i} 的分配方案:")
        visualize_agent(population[i], normal_points, danger_points)

'''