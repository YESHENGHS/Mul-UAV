import numpy as np
from itertools import product
from typing import List, Tuple
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from abc import ABC, abstractmethod

from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import os

class HazardZone(ABC):
    """危险区域基类"""

    def __init__(self, plane_type: str, spacing: float, offset: float = 0.0):
        """
        plane_type: 'x', 'y' or 'z'
        spacing: 点间距
        offset: 平面偏移量 (x/y/z坐标)
        """
        self.plane_type = plane_type
        self.spacing = spacing
        self.offset = offset  # 新增：平面偏移量

    @abstractmethod
    def generate_points(self) -> np.ndarray:
        pass

    @abstractmethod
    def is_inside(self, point: np.ndarray) -> bool:
        pass


class RectangleZone(HazardZone):
    def __init__(self, plane_type: str, bounds: Tuple[float, float, float, float],
                 spacing: float, offset: float = 0.0):
        super().__init__(plane_type, spacing, offset)
        self.bounds = bounds

    def generate_points(self) -> np.ndarray:
        a_min, a_max, b_min, b_max = self.bounds
        a_points = np.arange(a_min, a_max, self.spacing)
        b_points = np.arange(b_min, b_max, self.spacing)

        if self.plane_type == 'x':
            points = [[self.offset, a, b] for a, b in product(a_points, b_points)]  # 使用offset
        elif self.plane_type == 'y':
            points = [[a, self.offset, b] for a, b in product(a_points, b_points)]
        else:  # 'z'
            points = [[a, b, self.offset] for a, b in product(a_points, b_points)]

        return np.array(points)

    def is_inside(self, point: np.ndarray) -> bool:
        x, y, z = point
        a_min, a_max, b_min, b_max = self.bounds

        if self.plane_type == 'x' and np.isclose(x, self.offset):  # 使用isclose处理浮点精度
            return (a_min <= y <= a_max) and (b_min <= z <= b_max)
        elif self.plane_type == 'y' and np.isclose(y, self.offset):
            return (a_min <= x <= a_max) and (b_min <= z <= b_max)
        elif self.plane_type == 'z' and np.isclose(z, self.offset):
            return (a_min <= x <= a_max) and (b_min <= y <= b_max)
        return False


#三角形
class TriangleZone(HazardZone):
    def generate_points(self) -> np.ndarray:
        a_min, b_min = np.min(self.vertices, axis=0)
        a_max, b_max = np.max(self.vertices, axis=0)

        a_points = np.arange(a_min, a_max, self.spacing)
        b_points = np.arange(b_min, b_max, self.spacing)

        points = []
        for a, b in product(a_points, b_points):
            if self.point_in_triangle((a, b)):
                if self.plane_type == 'x':
                    points.append([self.offset, a, b])  # 使用offset
                elif self.plane_type == 'y':
                    points.append([a, self.offset, b])
                else:  # 'z'
                    points.append([a, b, self.offset])

        return np.array(points)

    def is_inside(self, point: np.ndarray) -> bool:
        x, y, z = point
        if self.plane_type == 'x' and np.isclose(x, self.offset):
            return self.point_in_triangle((y, z))
        elif self.plane_type == 'y' and np.isclose(y, self.offset):
            return self.point_in_triangle((x, z))
        elif self.plane_type == 'z' and np.isclose(z, self.offset):
            return self.point_in_triangle((x, y))
        return False

#圆
class CircleZone(HazardZone):
    def generate_points(self) -> np.ndarray:
        a_center, b_center = self.center
        a_min, a_max = a_center - self.radius, a_center + self.radius
        b_min, b_max = b_center - self.radius, b_center + self.radius

        a_points = np.arange(a_min, a_max, self.spacing)
        b_points = np.arange(b_min, b_max, self.spacing)

        points = []
        for a, b in product(a_points, b_points):
            if (a - self.center[0]) ** 2 + (b - self.center[1]) ** 2 <= self.radius ** 2:
                if self.plane_type == 'x':
                    points.append([self.offset, a, b])  # 使用offset
                elif self.plane_type == 'y':
                    points.append([a, self.offset, b])
                else:  # 'z'
                    points.append([a, b, self.offset])

        return np.array(points)

    def is_inside(self, point: np.ndarray) -> bool:
        x, y, z = point
        if self.plane_type == 'x' and np.isclose(x, self.offset):
            return (y - self.center[0]) ** 2 + (z - self.center[1]) ** 2 <= self.radius ** 2
        elif self.plane_type == 'y' and np.isclose(y, self.offset):
            return (x - self.center[0]) ** 2 + (z - self.center[1]) ** 2 <= self.radius ** 2
        elif self.plane_type == 'z' and np.isclose(z, self.offset):
            return (x - self.center[0]) ** 2 + (y - self.center[1]) ** 2 <= self.radius ** 2
        return False

#半圆
import numpy as np
from itertools import product
from typing import Tuple

import numpy as np
from typing import Tuple

import numpy as np
from typing import Tuple

class SemicircleZone(HazardZone):
    def __init__(
        self,
        center: Tuple[float, float],  # 圆心坐标 (a, b)
        radius: float,                # 半径
        plane_type: str,              # 平面类型 ('x', 'y', 'z')
        spacing: float,               # 点间距
        offset: float = 0.0,          # 平面偏移量
    ):
        super().__init__(plane_type=plane_type, spacing=spacing, offset=offset)
        self.center = center
        self.radius = radius

    def generate_points(self) -> np.ndarray:
        a_center, b_center = self.center

        # 仅生成半圆弧上的点（θ ∈ [0, π]）
        theta = np.linspace(0, np.pi, int(np.pi * self.radius / self.spacing) + 1)
        arc = [
            (a_center + self.radius * np.cos(angle), b_center + self.radius * np.sin(angle))
            for angle in theta
        ]

        # 根据 plane_type 转换为 3D 坐标
        points = []
        for a, b in arc:
            if self.plane_type == 'x':
                points.append([self.offset, a, b])
            elif self.plane_type == 'y':
                points.append([a, self.offset, b])
            elif self.plane_type == 'z':
                points.append([a, b, self.offset])

        return np.array(points)

    def is_inside(self, point: np.ndarray) -> bool:
        x, y, z = point
        a_center, b_center = self.center

        if self.plane_type == 'x' and np.isclose(x, self.offset):
            dist_sq = (y - a_center)**2 + (z - b_center)**2
            return np.isclose(dist_sq, self.radius**2) and (z >= b_center)

        elif self.plane_type == 'y' and np.isclose(y, self.offset):
            dist_sq = (x - a_center)**2 + (z - b_center)**2
            return np.isclose(dist_sq, self.radius**2) and (z >= b_center)

        elif self.plane_type == 'z' and np.isclose(z, self.offset):
            dist_sq = (x - a_center)**2 + (y - b_center)**2
            return np.isclose(dist_sq, self.radius**2) and (y >= b_center)

        return False



def generate_viewpoints(
        normal_zones: List[HazardZone],
        danger_zones: List[HazardZone],
        normal_spacing: float,
        danger_spacing: float
) -> Tuple[np.ndarray, np.ndarray]:
    """
    生成视点（改进版：自动删除危险区域内的普通视点）
    Parameters:
        normal_zones: 普通区域列表
        danger_zones: 危险区域列表
        normal_spacing: 普通区域视点间距
        danger_spacing: 危险区域视点间距
    Returns:
        normal_points: 普通视点数组（已删除危险区域部分）
        danger_points: 危险视点数组（仅包含危险区域内新生成的点）
    """
    # 1. 先生成所有普通视点
    all_normal_points = []
    for zone in normal_zones:
        zone.spacing = normal_spacing
        all_normal_points.append(zone.generate_points())

    if not all_normal_points:
        raise ValueError("至少需要定义一个普通区域")

    all_normal_points = np.vstack(all_normal_points)

    # 2. 找到所有需要被删除的普通视点（位于危险区域内的）
    delete_mask = np.zeros(len(all_normal_points), dtype=bool)
    for i, point in enumerate(all_normal_points):
        for zone in danger_zones:
            if zone.is_inside(point):
                delete_mask[i] = True
                break

    # 3. 保留安全的普通视点
    normal_safe = all_normal_points[~delete_mask]

    # 4. 生成新的危险视点（原始危险区域内的点，但用更密的间距）
    danger_points = []
    for zone in danger_zones:
        # 先检查这个危险区域是否在某个普通区域内（否则不应该生成）
        in_normal_zone = False
        for n_zone in normal_zones:
            # 比较平面类型和偏移量是否相同
            if (n_zone.plane_type == zone.plane_type and
                    np.isclose(n_zone.offset, zone.offset)):
                in_normal_zone = True
                break

        if in_normal_zone:
            zone.spacing = danger_spacing
            danger_points.append(zone.generate_points())

    danger_points = np.vstack(danger_points) if danger_points else np.array([])

    return normal_safe, danger_points


# 可视化（修改可视化函数以显示多个平面）
def visualize_points(normal_points, danger_points):
    fig = plt.figure(figsize=(12, 9))
    ax = fig.add_subplot(111, projection='3d')

    # 绘制点
    if len(normal_points) > 0:
        ax.scatter(normal_points[:, 0], normal_points[:, 1], normal_points[:, 2],
                   c='blue', alpha=0.6, s=30, label='普通视点')
    if len(danger_points) > 0:
        ax.scatter(danger_points[:, 0], danger_points[:, 1], danger_points[:, 2],
                   c='red', alpha=0.8, s=50, label='危险视点')

    # 关闭 XYZ 轴等比例缩放（允许自由拉伸）
    ax.set_box_aspect(None)  # 关键修改：让 XYZ 轴独立缩放
    # 或者也可以使用：
    # ax.axis('auto')

    # 如果不希望自动调整轴范围，可以手动设置（例如这里假设 X/Y 较短，Z 较长）
    ax.set_xlim(0, 20)
    ax.set_ylim(0, 20)
    ax.set_zlim(0, 20 * 1.5)  # 让 Z 轴比 XY 轴长 1.5 倍

    # 绘制坐标平面（透明灰色平面）
#    xx, yy = np.meshgrid(np.linspace(0, 20, 2), np.linspace(0, 20, 2))
#    for z_offset in [0.0, 2.0]:  # 绘制两个 Z 平面
#        ax.plot_surface(xx, yy, np.full_like(xx, z_offset), alpha=0.1, color='gray')
#
#    # 绘制其他平面（X、Y）
#    ax.plot_surface(np.full_like(xx, 5.0), xx, yy, alpha=0.1, color='green')  # X=5
#    ax.plot_surface(xx, np.full_like(xx, -3.0), yy, alpha=0.1, color='blue')  # Y=-3

    ax.set_xlabel('X轴')
    ax.set_ylabel('Y轴')
    ax.set_zlabel('Z轴')
    ax.set_title('自由缩放的视点分布图')
    plt.legend()
    plt.tight_layout()
    plt.show()


def split_and_visualize_paths(normal_points: np.ndarray, danger_points: np.ndarray, max_step=6):
    """
    最终增强版路径规划：
    - 保留所有原有功能
    - 新增路径长度计算
    - 新增飞行时间估算(基于速度5m/s)
    """

    def calculate_path_length(path):
        """计算路径总长度"""
        if len(path) < 2:
            return 0.0
        total = 0.0
        for i in range(1, len(path)):
            total += np.linalg.norm(path[i] - path[i - 1])
        return total

    def get_reachable_points(current_point, points, max_distance):
        """获取当前点的可达点(距离<=max_distance)"""
        if len(points) == 0:
            return np.array([]), np.array([])
        distances = np.linalg.norm(points - current_point, axis=1)
        mask = distances <= max_distance
        return points[mask], np.where(mask)[0]

    def find_next_point(current_point, remaining_points, z_tolerance=0.1):
        """寻找下一个目标点(智能切换平面)"""
        # 1. 优先在同一Z平面寻找(严格模式)
        same_z_mask = np.abs(remaining_points[:, 2] - current_point[2]) < z_tolerance
        same_z_points = remaining_points[same_z_mask]

        # 先找步长内的点
        reachable, indices = get_reachable_points(current_point, same_z_points, max_step)
        if len(reachable) > 0:
            # 选择最近的点
            distances = np.linalg.norm(reachable - current_point, axis=1)
            nearest_idx = np.argmin(distances)
            return reachable[nearest_idx], np.where(same_z_mask)[0][indices[nearest_idx]]

        # 2. 如果同平面没有，寻找邻近Z平面(仍然优先步长内)
        unique_z = np.unique(remaining_points[:, 2])
        z_distances = np.abs(unique_z - current_point[2])
        for z in unique_z[np.argsort(z_distances)]:
            if z == current_point[2]:  # 已检查过当前Z平面
                continue

            z_mask = np.abs(remaining_points[:, 2] - z) < z_tolerance
            z_points = remaining_points[z_mask]
            reachable, indices = get_reachable_points(current_point, z_points, max_step)
            if len(reachable) > 0:
                distances = np.linalg.norm(reachable - current_point, axis=1)
                nearest_idx = np.argmin(distances)
                return reachable[nearest_idx], np.where(z_mask)[0][indices[nearest_idx]]

        # 3. 如果没有任何步长内的点，强制选择最近的点(突破步长限制)
        if len(remaining_points) > 0:
            distances = np.linalg.norm(remaining_points - current_point, axis=1)
            nearest_idx = np.argmin(distances)
            return remaining_points[nearest_idx], nearest_idx

        return None, None

    def build_path(start_point, points):
        """构建路径(自动处理不可达点)"""
        path = [start_point]
        remaining_points = np.array([p for p in points if not np.all(p == start_point)])

        # 统计突破步长的次数
        overstep_count = 0
        overstep_distances = []

        while len(remaining_points) > 0:
            current_point = path[-1]

            # 寻找下一个点
            next_point, idx = find_next_point(current_point, remaining_points)

            if next_point is None:
                break

            # 检查是否突破步长限制
            distance = np.linalg.norm(next_point - current_point)
            if distance > max_step:
                overstep_count += 1
                overstep_distances.append(distance)
                print(f"! 突破步长限制: {distance:.2f} (从 {current_point} 到 {next_point})")

            # 更新路径和剩余点
            path.append(next_point)
            remaining_points = np.delete(remaining_points, idx, axis=0)

        print(f"路径完成，共突破步长限制 {overstep_count} 次")
        if overstep_count > 0:
            print(f"最大突破距离: {max(overstep_distances):.2f}")
        return np.array(path)

    # 合并所有点并按Z轴分层
    all_points = np.vstack([normal_points, danger_points]) if danger_points.size > 0 else normal_points
    if all_points.size == 0:
        print("没有点可处理")
        return

    print(f"总点数: {len(all_points)} | 首选步长限制: {max_step}")
    print("假设无人机速度: 5 m/s\n")

    # 分成三层
    min_z, max_z = np.min(all_points[:, 2]), np.max(all_points[:, 2])
    boundary1 = min_z + (max_z - min_z) / 3
    boundary2 = min_z + 2 * (max_z - min_z) / 3

    layer1 = all_points[all_points[:, 2] < boundary1]
    layer2 = all_points[(all_points[:, 2] >= boundary1) & (all_points[:, 2] < boundary2)]
    layer3 = all_points[all_points[:, 2] >= boundary2]

    # 为每层选择起始点
    def get_start_point(points):
        if len(points) == 0:
            return None
        # 选择Z轴最低点中最角落的点
        min_z = np.min(points[:, 2])
        candidates = points[points[:, 2] == min_z]
        start_idx = np.argmin(candidates[:, 0] + candidates[:, 1])
        return candidates[start_idx]

    start_points = [get_start_point(layer) for layer in [layer1, layer2, layer3]]

    # 构建路径并计算长度和时间
    drone_paths = []
    path_lengths = []
    flight_times = []

    for i, (layer, start) in enumerate(zip([layer1, layer2, layer3], start_points), 1):
        if start is None:
            drone_paths.append(np.array([]))
            path_lengths.append(0.0)
            flight_times.append(0.0)
            print(f"无人机{i}: 无有效点")
            continue

        print(f"\n=== 规划无人机{i}路径 ===")
        print(f"层高度范围: {layer[0, 2]:.1f}-{layer[-1, 2]:.1f} | 点数: {len(layer)}")

        path = build_path(start, layer)
        drone_paths.append(path)

        # 计算路径长度和时间 (新增部分)
        length = calculate_path_length(path)
        time = length / 5  # 飞行时间(秒)

        path_lengths.append(length)
        flight_times.append(time)

        coverage = len(path) / len(layer) * 100
        print(f"路径完成度: {coverage:.1f}% ({len(path)}/{len(layer)})")
        print(f"路径总长度: {length:.2f} 米")
        print(f"预计飞行时间: {time:.1f} 秒 ({time / 60:.1f} 分钟)")

    # 计算总时间 (新增部分)
    total_time = max(flight_times) if flight_times else 0
    print(f"\n== 任务总览 ==")
    print(f"最长无人机飞行时间: {total_time:.1f} 秒 ({total_time / 60:.1f} 分钟)")
    print("各无人机详情:")
    for i in range(3):
        status = f"无人机{i + 1}: " + (
            f"{path_lengths[i]:.2f} 米 | {flight_times[i]:.1f} 秒" if drone_paths[i].size > 0 else "未分配任务")
        print(status)

    # 可视化
    fig = plt.figure(figsize=(15, 10))
    ax = fig.add_subplot(111, projection='3d')

    colors = ['blue', 'red', 'green']
    labels = [f'无人机1 (Z < {boundary1:.1f}) - {flight_times[0]:.1f}s',
              f'无人机2 ({boundary1:.1f} ≤ Z < {boundary2:.1f}) - {flight_times[1]:.1f}s',
              f'无人机3 (Z ≥ {boundary2:.1f}) - {flight_times[2]:.1f}s']

    for i, (path, color, label) in enumerate(zip(drone_paths, colors, labels), 1):
        if len(path) > 1:
            # 绘制路径线
            line = ax.plot(path[:, 0], path[:, 1], path[:, 2],
                           color=color, linestyle='-', alpha=0.7, label=label)[0]

            # 标记起点和终点
            ax.scatter(path[0, 0], path[0, 1], path[0, 2],
                       color=color, marker='o', s=150, edgecolors='k', linewidth=1)
            ax.scatter(path[-1, 0], path[-1, 1], path[-1, 2],
                       color=color, marker='*', s=300, edgecolors='k', linewidth=1)

            # 标记突破步长的线段
            for j in range(1, len(path)):
                dist = np.linalg.norm(path[j] - path[j - 1])
                if dist > max_step:
                    ax.plot(path[j - 1:j + 1, 0], path[j - 1:j + 1, 1], path[j - 1:j + 1, 2],
                            color=color, linestyle=':', linewidth=2, alpha=0.9)

    ax.set_xlabel('X轴', fontsize=12)
    ax.set_ylabel('Y轴', fontsize=12)
    ax.set_zlabel('Z轴', fontsize=12)
    ax.set_title(f'无人机路径规划 (步长限制:{max_step} | 最长飞行:{total_time:.1f}s)', fontsize=14)

    # 添加图例
    from matplotlib.lines import Line2D
    legend_elements = [
        Line2D([0], [0], color='blue', lw=2, label=labels[0]),
        Line2D([0], [0], color='red', lw=2, label=labels[1]),
        Line2D([0], [0], color='green', lw=2, label=labels[2]),
        Line2D([0], [0], marker='o', color='w', label='起点',
               markerfacecolor='k', markersize=10),
        Line2D([0], [0], marker='*', color='w', label='终点',
               markerfacecolor='k', markersize=15),
        Line2D([0], [0], color='k', linestyle=':', lw=2,
               label=f'突破步长(>{max_step})')
    ]
    ax.legend(handles=legend_elements, loc='upper right', fontsize=10)

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    # 普通区域（多个平面）
    normal_zones = [
        RectangleZone('z', (0, 15, 0, 50), 5.0, offset=15.0),  # Z=平面
        RectangleZone('x', (0, 50, 0, 15), 5.0, offset=0.0),  # X=平面
        RectangleZone('y', (0, 15, 0, 15), 5.0, offset=49.0),  # Y=平面

        RectangleZone('x', (0, 50, 0, 15), 5.0, offset=12.0),  # X=平面

        RectangleZone('x', (5, 15, -25, -3), 5.0, offset=0.0),  # X=平面
        RectangleZone('x', (32, 42, -25, -3), 5.0, offset=0.0),  # X=平面

        RectangleZone('x', (5, 15, -25, -3), 5.0, offset=12.0),  # X=平面
        RectangleZone('x', (5, 15, -25, -3), 5.0, offset=12.0),  # X=平面

        RectangleZone('x', (18, 29, -3, -0), 5.0, offset=12.0),  # X=平面
        RectangleZone('x', (18, 29, -3, 0), 5.0, offset=0.0),  # X=平面

        RectangleZone('y', (0, 15, -25, -3), 5.0, offset=5.0),  # Y=平面
        RectangleZone('y', (0, 15, -25, -3), 5.0, offset=42.0),  # Y=平面

        RectangleZone('y', (0, 15, -25, -15), 5.0, offset=15.0),  # Y=平面
        RectangleZone('y', (0, 15, -25, -15), 5.0, offset=32.0),  # Y=平面,

        # ✅ 修正后的 SemicircleZone，按用途调整圆心、半径和所在的平面
        SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=12.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        ),

        SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=9.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        ),

        SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=6.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        ),

        SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=3.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        )
    ]

    # 危险区域（需要覆盖部分普通区域）
    danger_zones = [
        RectangleZone('z', (5, 10, 20, 25), 1.0, offset=15.0),   # 覆盖Z=0平面的部分区域 要注意，危险区域要在安全区域内奥
        #CircleZone('x', (10, 10), 4.0, 0.8, offset=5.0)        # 覆盖X=5平面的圆形区域
        RectangleZone('y', (5, 10, -25, -20), 5.0, offset=5.0),
        RectangleZone('y', (5, 10, -25, -20), 5.0, offset=42.0),

    ]

    # 生成视点（自动处理覆盖关系）
    normal_points, danger_points = generate_viewpoints(
        normal_zones=normal_zones,
        danger_zones=danger_zones,
        normal_spacing=3,
        danger_spacing=1.5
    )

    # 可视化（会发现危险区域内的普通点被自动删除）
    visualize_points(normal_points, danger_points)
    split_and_visualize_paths(normal_points, danger_points ,max_step=6)