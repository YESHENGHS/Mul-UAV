# 野生陆生海参
# EditTime:2025/4/23 23:53
import UAVpot2
import visualize
import popInitTest2
#快速收敛的变异和交叉

if __name__ == "__main__":
    # 配置参数
    config = {
        "max_generations": 100,
        "num_agents": 50,
        "num_uavs": 3,
        "max_step_distance": 12,
        "energy_params": {"xy": 0.1, "z": 0.2},
        "weights": {"time": 0.1, "energy": 0.2, "std": 0.7},
        "speed":5.0
    }

    # 普通区域（多个平面）
    normal_zones = [
        popInitTest2.RectangleZone('z', (0, 15, 0, 50), 5.0, offset=15.0),  # Z=平面
        popInitTest2.RectangleZone('x', (0, 50, 0, 15), 5.0, offset=0.0),  # X=平面
        popInitTest2.RectangleZone('y', (0, 15, 0, 15), 5.0, offset=50.0),  # Y=平面

        popInitTest2.RectangleZone('x', (0, 50, 0, 15), 5.0, offset=12.0),  # X=平面

        popInitTest2.RectangleZone('x', (5, 15, -25, -3), 5.0, offset=0.0),  # X=平面
        popInitTest2.RectangleZone('x', (32, 42, -25, -3), 5.0, offset=0.0),  # X=平面

        popInitTest2.RectangleZone('x', (5, 15, -25, -3), 5.0, offset=12.0),  # X=平面
        popInitTest2.RectangleZone('x', (5, 15, -25, -3), 5.0, offset=12.0),  # X=平面

        popInitTest2.RectangleZone('x', (18, 29, -3, -0), 5.0, offset=12.0),  # X=平面
        popInitTest2.RectangleZone('x', (18, 29, -3, 0), 5.0, offset=0.0),  # X=平面

        popInitTest2.RectangleZone('y', (0, 15, -25, -3), 5.0, offset=5.0),  # Y=平面
        popInitTest2.RectangleZone('y', (0, 15, -25, -3), 5.0, offset=42.0),  # Y=平面

        popInitTest2.RectangleZone('y', (0, 15, -25, -15), 5.0, offset=15.0),  # Y=平面
        popInitTest2.RectangleZone('y', (0, 15, -25, -15), 5.0, offset=32.0),  # Y=平面,

        # ✅ 修正后的 SemicircleZone，按用途调整圆心、半径和所在的平面
        popInitTest2.SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=12.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        ),

        popInitTest2.SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=9.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        ),

        popInitTest2.SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=6.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        ),

        popInitTest2.SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=3.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        )
    ]

    # 危险区域（需要覆盖部分普通区域）
    danger_zones = [
        popInitTest2.RectangleZone('z', (5, 10, 20, 25), 1.0, offset=15.0),   # 覆盖Z=0平面的部分区域 要注意，危险区域要在安全区域内奥
        #CircleZone('x', (10, 10), 4.0, 0.8, offset=5.0)        # 覆盖X=5平面的圆形区域
        popInitTest2.RectangleZone('y', (5, 10, -25, -20), 5.0, offset=5.0),
        popInitTest2.RectangleZone('y', (5, 10, -25, -20), 5.0, offset=42.0),

    ]


    # 生成视点（自动处理覆盖关系）
    normal_points, danger_points = popInitTest2.generate_viewpoints(
        normal_zones=normal_zones,
        danger_zones=danger_zones,
        normal_spacing=4.0,
        danger_spacing=2
    )

    optimizer = UAVpot2.UAVOptimizer(config)
    results = optimizer.run(normal_points, danger_points)

    print(f"\n最优解耗时: {min(results['fitness_history']):.2f}")
    print(f"最优路径点示例: {results['best_solution'][0]['points'][:3]}...")

# 可视化前个代理
    print(f"\n可视化代理 {1} 的分配方案:")
    visualize.visualize_agent(results['best_solution'], normal_points, danger_points)