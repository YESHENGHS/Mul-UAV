import numpy as np
import random
from typing import List, Dict, Tuple
from scipy.spatial.distance import cdist

def generate_population(normal_points: np.ndarray,
                        danger_points: np.ndarray,
                        num_agents: int = 100,
                        num_uavs: int = 3,
                        max_step_distance: float = 3.0) -> List[List[Dict]]:
    """
    生成包含最大步长约束的种群

    新增参数:
    - max_step_distance: 连续视点间最大允许距离(米)
    """

    def create_constrained_trajectory(indices: np.ndarray,
                                      all_points: np.ndarray,
                                      first_point: bool = True) -> np.ndarray:
        """
        生成符合间距约束的轨迹点序列（修复版本）
        """
        if len(indices) == 0:
            return np.empty((0, 3))

        remaining = list(indices.copy())
        trajectory = []
        last_point_coords = None  # 改为显式坐标存储

        # 选择起始点(最靠近中心的点)
        if first_point:
            center = np.mean(all_points, axis=0)
            starter = remaining[np.argmin([np.linalg.norm(all_points[i] - center)
                                           for i in remaining])]
            trajectory.append(starter)
            remaining.remove(starter)
            last_point_coords = all_points[starter]  # 存储坐标而非索引

        while remaining:
            # 寻找最近合规点
            candidates = []

            for idx in remaining:
                current_point = all_points[idx]
                if last_point_coords is not None:
                    dist = np.linalg.norm(current_point - last_point_coords)
                    if dist <= max_step_distance:
                        candidates.append((dist, idx))
                else:
                    candidates.append((0, idx))  # 没有前点时距离设为0

            if candidates:
                # 优先选择最近点
                candidates.sort()
                selected_idx = candidates[0][1]
                trajectory.append(selected_idx)
                last_point_coords = all_points[selected_idx]
                remaining.remove(selected_idx)
            else:
                # 无合规点则选择最近点并插值
                dists = [np.linalg.norm(all_points[idx] - last_point_coords)
                         for idx in remaining]
                nearest_idx = remaining[np.argmin(dists)]
                nearest_dist = np.min(dists)

                # 计算需要插入的中间点数
                num_segments = int(np.ceil(nearest_dist / max_step_distance))
                interpolated = np.linspace(last_point_coords,
                                           all_points[nearest_idx],
                                           num=num_segments + 1)

                # 添加中间点（使用负索引标识）
                new_points = np.vstack([all_points, interpolated[1:-1]])
                virtual_indices = -np.arange(1, len(interpolated))  # 负索引

                # 更新轨迹
                trajectory.extend(virtual_indices.tolist())
                trajectory.append(nearest_idx)

                # 更新数据结构
                all_points = new_points
                last_point_coords = all_points[nearest_idx]
                remaining.remove(nearest_idx)

        # 转换为实际坐标（过滤掉中间点）
        return all_points[[i for i in trajectory if i >= 0]]

    # 输入验证
    if max_step_distance <= 0:
        raise ValueError("最大步长必须为正数")

    # 合并所有点
    all_points = np.vstack([normal_points, danger_points])
    all_points = np.unique(all_points, axis=0)  # 确保无重复点

    num_normal = len(normal_points)
    num_danger = len(danger_points)
    point_types = np.concatenate([np.zeros(num_normal), np.ones(num_danger)])

    population = []

    for _ in range(num_agents):
        agent = []
        indices = np.random.permutation(len(all_points))

        # 动态分配点数
        points_per_uav = np.array_split(indices, num_uavs)

        start_idx = 0
        for _ in range(num_agents):
            agent = []
            indices = np.random.permutation(len(all_points))

            points_per_uav = np.array_split(indices, num_uavs)
            for uav_id, indices in enumerate(points_per_uav):
                points = create_constrained_trajectory(
                    indices,
                    all_points.copy(),
                    uav_id == 0
                )

                # 分类点类型
                normal_mask = np.array([i < len(normal_points)
                                        for i in indices if i >= 0])
                agent.append({
                    'points': points,
                    'normals': indices[indices < len(normal_points)],
                    'dangers': indices[indices >= len(normal_points)] - len(normal_points)
                })

            population.append(agent)

        return population

'''

if __name__ == "__main__":

    # 测试数据生成
    np.random.seed(42)
    normal_pts = np.random.uniform(0, 10, (150, 3))
    danger_pts = np.random.uniform(5, 8, (50, 3))

    # 生成带约束的种群 (最大步长2.5米)
    constrained_pop = generate_population(normal_pts, danger_pts,
                                          num_agents=100,
                                          num_uavs=3,
                                          max_step_distance=2.5)
    # 验证约束合规性
    def check_constraints(pop, max_dist):
        violations = 0
        for agent in pop:
            for uav in agent:
                pts = uav['points']
                if len(pts) > 1:
                    dists = np.linalg.norm(pts[1:] - pts[:-1], axis=1)
                    violations += np.sum(dists > max_dist * 1.05)  # 允许5%容差

        print(f"在{len(pop)}个代理中发现{violations}次间距违规")


    check_constraints(constrained_pop, 2.5)  # 应输出0或极少数违规
    def analyze_population(pop):
        points_per_uav = []
        normal_ratios = []

        for agent in pop:
            for uav in agent:
                points_per_uav.append(len(uav['points']))
                if len(uav['points']) > 0:
                    normal_ratios.append(len(uav['normals']) / len(uav['points']))

        print("\n种群统计信息:")
        print(f"总代理数: {len(pop)}")
        print(f"每代理无人机数: {len(pop[0])}")
        print(f"平均每无人机分配点数: {np.mean(points_per_uav):.2f}")
        print(f"最小/最大分配点数: {np.min(points_per_uav)}/{np.max(points_per_uav)}")
        print(f"平均普通点占比: {np.mean(normal_ratios) * 100:.1f}%")

    analyze_population(constrained_pop)

print(constrained_pop)




# 可视化示例代理
def visualize_agent(agent_trajectories, normal_pts, danger_pts):
    try:
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D

        fig = plt.figure(figsize=(14, 10))
        ax = fig.add_subplot(111, projection='3d')

        colors = ['red', 'green', 'blue']
        labels = ['UAV A', 'UAV B', 'UAV C']

        # 绘制原始点集
        ax.scatter(normal_pts[:, 0], normal_pts[:, 1], normal_pts[:, 2],
                   c='gray', alpha=0.2, s=15, label='All Normal Points')
        ax.scatter(danger_pts[:, 0], danger_pts[:, 1], danger_pts[:, 2],
                   c='orange', alpha=0.3, s=20, label='All Danger Points')

        # 绘制分配结果
        for i, uav in enumerate(agent_trajectories):
            pts = uav['points']
            if len(pts) > 0:
                ax.scatter(pts[:, 0], pts[:, 1], pts[:, 2],
                           color=colors[i], s=50, label=labels[i])

                # 按照轨迹顺序连线
                ax.plot(pts[:, 0], pts[:, 1], pts[:, 2],
                        color=colors[i], linestyle=':', alpha=0.6, linewidth=1)

        ax.set_xlabel('X轴')
        ax.set_ylabel('Y轴')
        ax.set_zlabel('Z轴')
        plt.title('示例代理的无人机轨迹分配 (3架无人机)')
        plt.legend()
        plt.tight_layout()
        plt.show()
    except ImportError:
        print("Matplotlib未安装，跳过可视化")


# 可视化前3个代理
for i in range(3):
    print(f"\n可视化代理 {i} 的分配方案:")
    visualize_agent(constrained_pop[i], normal_pts, danger_pts)
        
'''