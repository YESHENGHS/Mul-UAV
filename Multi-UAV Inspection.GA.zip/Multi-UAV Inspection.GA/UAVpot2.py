import pop2Track
import ObjectFunction
import GA
import random
from typing import List, Dict, Tuple
import time
import numpy as np
from copy import deepcopy
import visualize


class UAVOptimizer:
    def __init__(self, config: Dict):
        """
        config示例:
        {
            "max_generations": 100,
            "num_agents": 100,
            "num_uavs": 3,
            "max_step_distance": 3.0,
            "energy_params": {"xy": 0.1, "z": 0.2},
            "weights": {"time": 0.5, "energy": 0.3, "std": 0.2}
            force_threshold : zui da  xian zhi lu jing :10
            "speed":5.0
        }
        """
        self.config = config

    def run(self, normal_points: np.ndarray, danger_points: np.ndarray) -> Dict:
        """执行完整优化流程"""
        results = {
            'best_solution': None,
            'fitness_history': [],
            'execution_time': 0
        }


        # 1. 初始化种群
        population = pop2Track.generate_population(
            normal_points, danger_points,
            num_agents=self.config['num_agents'],
            num_uavs=self.config['num_uavs'],
            max_step_distance=self.config['max_step_distance']
        )

        # 2. 初始评估
        population = ObjectFunction.calculate_objectives(
            population,
            speed = self.config['speed'],
            energy_xy=self.config['energy_params']['xy'],
            energy_z=self.config['energy_params']['z']
        )

        fitness = ObjectFunction.weighted_objective(
            population,
            time_weight=self.config['weights']['time'],
            energy_weight=self.config['weights']['energy'],
            std_weight=self.config['weights']['std']
        )

        best_idx = np.argmin(fitness)
        results['fitness_history'].append(fitness[best_idx])

        # 3. 进化循环
        start_time = time.time()
        for gen in range(1, self.config['max_generations'] + 1):
            # 选择
            population, fitness = GA.selection_operator(
                population, fitness,
                elite_ratio=0.1
            )

            # 交叉
            population = GA.crossover(
                population,
                max_step_distance=self.config['max_step_distance']
            )

            # 变异
            population = GA.mutation(
                population,
                current_gen = gen,
                max_generations=self.config['max_generations']
            )

            # 重新评估
            population = ObjectFunction.calculate_objectives(population)
            fitness = ObjectFunction.weighted_objective(population)

            # 记录最佳解
            current_best = np.min(fitness)
            results['fitness_history'].append(current_best)

            if gen % 10 == 0:
                print(f"Gen {gen}: Best = {current_best:.2f}")

        # 保存结果
        results['execution_time'] = time.time() - start_time
        results['best_solution'] = deepcopy(population[best_idx])
        visualize.plot_convergence(results['fitness_history'])

        return results

'''
if __name__ == "__main__":

    # 配置参数
    config = {
        "max_generations": 100,
        "num_agents": 50,
        "num_uavs": 3,
        "max_step_distance": 2.5,
        "energy_params": {"xy": 0.1, "z": 0.2},
        "weights": {"time": 0.5, "energy": 0.3, "std": 0.2},
        "max_step_distance_cross": 10 ,
        "speed":5.0
    }

    danger_zones = [
        ['x', 10, 20, 5, 15],  # X=0平面上的危险区 (y_min, y_max, z_min, z_max)
        ['y', 10, 20, 5, 15],  # Y=0平面上的危险区 (x_min, x_max, z_min, z_max)
    ]

    # 平面参数设置 (现在可以接受零范围)
    x_plane_size = (0, 50, 0, 25)  # X=0平面: y_min, y_max, z_min, z_max
    y_plane_size = (0, 50, 0, 25)  # Y=0平面: x_min, x_max, z_min, z_max


    normal, danger = popInit.generate_viewpoints(
        danger_zones=danger_zones,
        normal_spacing=3,
        danger_spacing=1.75,
        x_plane_size=x_plane_size,
        y_plane_size=y_plane_size,
        z_range=(0, 5)  # 全局Z范围限制
    )

    optimizer = UAVOptimizer(config)
    results = optimizer.run(normal, danger)

    print(f"\n最优解耗时: {min(results['fitness_history']):.2f}")
    print(f"最优路径点示例: {results['best_solution'][0]['points'][:3]}...")
'''