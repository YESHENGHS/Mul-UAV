import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def generate_grid_points(rows=5, cols=5, spacing=1.0, y_value=0.0):
    """生成XZ平面上的等间距3D点（固定Y值）"""
    x = np.linspace(0, (cols-1)*spacing, cols)
    z = np.linspace(0, (rows-1)*spacing, rows)
    xx, zz = np.meshgrid(x, z)
    yy = np.full_like(xx, y_value)
    return np.column_stack([xx.ravel(), yy.ravel(), zz.ravel()])

def serpentine_path(points, rows, cols):
    """蛇形路径规划（XZ平面版）"""
    grid = points.reshape(rows, cols, 3)
    path = []
    for i in range(rows):
        if i % 2 == 0:  # 从左到右
            path.extend(grid[i])
        else:           # 从右到左
            path.extend(grid[i][::-1])
    return np.array(path)

# 参数设置
ROWS, COLS = 6, 8       # 网格行列数（注意此时ROWS是Z方向）
SPACING = 2.0           # 点间距(米)
Y_VALUE = 0.0           # 固定Y坐标值

# 生成点阵（XZ平面）
points = generate_grid_points(rows=ROWS, cols=COLS,
                             spacing=SPACING, y_value=Y_VALUE)

# 路径规划
path = serpentine_path(points, ROWS, COLS)

# 可视化
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# 绘制所有点
ax.scatter(points[:,0], points[:,1], points[:,2],
           c='blue', s=50, depthshade=True, label='航点')

# 绘制路径
ax.plot(path[:,0], path[:,1], path[:,2],
        'r-', linewidth=2, marker='o', markersize=4, label='飞行路径')

# 标记起点终点
ax.scatter(path[0,0], path[0,1], path[0,2],
           c='green', s=150, marker='*', label='起点')
ax.scatter(path[-1,0], path[-1,1], path[-1,2],
           c='black', s=150, marker='X', label='终点')

# 设置视角（更适合观察XZ平面）
ax.view_init(elev=30, azim=-60)

# 坐标轴标签和标题
ax.set_title(f'XZ平面蛇形路径 ({ROWS}x{COLS}网格 | 间距: {SPACING}m | Y={Y_VALUE}m)', pad=15)
ax.set_xlabel('X轴 (m)')
ax.set_ylabel('Y轴 (m)')
ax.set_zlabel('Z轴 (高度)')
ax.legend(loc='upper right')

# 设置坐标轴范围
x_pad = SPACING * 0.5
z_pad = SPACING * 0.5
ax.set_xlim(-x_pad, (COLS-1)*SPACING + x_pad)
ax.set_zlim(-z_pad, (ROWS-1)*SPACING + z_pad)

plt.tight_layout()
plt.show()
