import numpy as np
from typing import List, Dict


def calculate_objectives(population: List[List[Dict]],
                         speed: float = 5.0,  # 无人机速度(m/s)
                         energy_xy: float = 0.1,  # 水平方向能耗系数(能量单位/米)
                         energy_z: float = 0.2,  # 垂直方向能耗系数(能量单位/米)
                         ) -> List[List[Dict]]:
    """
    计算population中每个智能体的三个目标函数值并更新数据结构

    参数:
        population: 输入的种群数据
        speed: 无人机恒定飞行速度(m/s)
        energy_xy: x-y平面每米能耗
        energy_z: z轴每米能耗

    返回:
        更新后的population，包含新增的目标函数值字段
    """
    for agent in population:
        # 存储每架无人机的计算结果
        time_per_uav = []
        energy_per_uav = []
        path_lengths = []

        for uav in agent:
            points = uav['points']

            # 1. 计算路径长度
            if len(points) < 2:
                path_length = 0.0
            else:
                # 计算相邻点间的三维距离
                deltas = np.diff(points, axis=0)
                xy_distances = np.linalg.norm(deltas[:, :2], axis=1)  # x-y距离
                z_distances = np.abs(deltas[:, 2])  # z距离
                segment_lengths = np.linalg.norm(deltas, axis=1)  # 总距离
                path_length = np.sum(segment_lengths)

                # 2. 计算能源消耗 (分开计算xy和z)
                energy_xy_consumed = np.sum(xy_distances) * energy_xy
                energy_z_consumed = np.sum(z_distances) * energy_z
                total_energy = energy_xy_consumed + energy_z_consumed

            # 3. 计算时间消耗
            time_consumed = path_length / speed

            # 存储单架无人机的计算结果
            uav['time_consumed'] = time_consumed
            uav['energy_consumed'] = total_energy
            uav['path_length'] = path_length

            # 收集群体计算数据
            time_per_uav.append(time_consumed)
            energy_per_uav.append(total_energy)
            path_lengths.append(path_length)

        # 计算群体级指标
        agent_time = max(time_per_uav)  # 取最长耗时
        total_energy = sum(energy_per_uav)
        path_std = np.std(path_lengths) if len(path_lengths) > 1 else 0.0

        # 添加到agent的每个uav中（保持数据一致性）
        for uav in agent:
            uav['group_time'] = agent_time
            uav['group_energy'] = total_energy
            uav['group_path_std'] = path_std
    return population


def weighted_objective(population: List[List[Dict]],
                       time_weight: float = 0.5,
                       energy_weight: float = 0.3,
                       std_weight: float = 0.2) -> np.ndarray:
    """
    计算加权综合目标函数值

    参数:
        time_weight: 时间权重
        energy_weight: 能耗权重
        std_weight: 标准差权重

    返回:
        每个智能体的综合适应度值数组
    """
    fitness = []

    for agent in population:
        # 每个agent的所有uav共享相同的群体指标
        sample_uav = agent[0]

        # 归一化处理（假设已进行种群级别的归一化）
        time_obj = sample_uav['group_time']
        energy_obj = sample_uav['group_energy']
        std_obj = sample_uav['group_path_std']

        # 加权求和
        combined = (time_weight * time_obj +
                    energy_weight * energy_obj +
                    std_weight * std_obj)
        fitness.append(combined)

    return np.array(fitness)

'''
# 使用示例
if __name__ == "__main__":

    # 新的危险区定义格式：
    # ['x'/'y', 各轴最小/最大值] 分别对应X=0或Y=0平面
    danger_zones = [
        ['x', 10, 20, 5, 15],  # X=0平面上的危险区 (y_min, y_max, z_min, z_max)
        ['y', 10, 20, 5, 15],  # Y=0平面上的危险区 (x_min, x_max, z_min, z_max)
    ]

    # 平面参数设置 (现在可以接受零范围)
    x_plane_size = (0, 50, 0, 25)  # X=0平面: y_min, y_max, z_min, z_max
    y_plane_size = (0, 50, 0, 25)  # Y=0平面: x_min, x_max, z_min, z_max

    # 生成视点
    normal_points, danger_points = popInit.generate_viewpoints(
        danger_zones=danger_zones,
        normal_spacing=3,
        danger_spacing=1.75,
        x_plane_size=x_plane_size,
        y_plane_size=y_plane_size,
        z_range=(0, 5)  # 全局Z范围限制
    )

    # 生成种群 (100个代理，每个代理3架无人机)
    population = pop2Track.generate_population(normal_points, danger_points, num_agents=100, num_uavs=3)


    # 假设已有population数据
    updated_pop = calculate_objectives(population)

    # 计算加权适应度
    fitness_values = weighted_objective(updated_pop)

    # 查看第一个智能体的完整数据
    print("First agent details:")
    for uav_id, uav in enumerate(updated_pop[0]):
        print(f"\nUAV {uav_id}:")
        print(f"Points shape: {uav['points'].shape}")
        print(f"Normals: {uav['normals']}")
        print(f"Dangers: {uav['dangers']}")
        print(f"Time consumed: {uav['time_consumed']:.2f}s")
        print(f"Energy consumed: {uav['energy_consumed']:.2f} units")
        print(f"Path length: {uav['path_length']:.2f}m")
        print(f"Group time: {uav['group_time']:.2f}s")
        print(f"Group energy: {uav['group_energy']:.2f} units")
        print(f"Group path std: {uav['group_path_std']:.2f}m")

    print("second agent details:")
    for uav_id, uav in enumerate(updated_pop[1]):
        print(f"\nUAV {uav_id}:")
        print(f"Points shape: {uav['points'].shape}")
        print(f"Normals: {uav['normals']}")
        print(f"Dangers: {uav['dangers']}")
        print(f"Time consumed: {uav['time_consumed']:.2f}s")
        print(f"Energy consumed: {uav['energy_consumed']:.2f} units")
        print(f"Path length: {uav['path_length']:.2f}m")
        print(f"Group time: {uav['group_time']:.2f}s")
        print(f"Group energy: {uav['group_energy']:.2f} units")
        print(f"Group path std: {uav['group_path_std']:.2f}m")

    print("\nFitness values for all agents:")
    print(fitness_values)

'''