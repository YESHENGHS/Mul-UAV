import numpy as np
from itertools import product
from typing import List, Tuple
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from abc import ABC, abstractmethod

from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import os

class HazardZone(ABC):
    """危险区域基类"""

    def __init__(self, plane_type: str, spacing: float, offset: float = 0.0):
        """
        plane_type: 'x', 'y' or 'z'
        spacing: 点间距
        offset: 平面偏移量 (x/y/z坐标)
        """
        self.plane_type = plane_type
        self.spacing = spacing
        self.offset = offset  # 新增：平面偏移量

    @abstractmethod
    def generate_points(self) -> np.ndarray:
        pass

    @abstractmethod
    def is_inside(self, point: np.ndarray) -> bool:
        pass


class RectangleZone(HazardZone):
    def __init__(self, plane_type: str, bounds: Tuple[float, float, float, float],
                 spacing: float, offset: float = 0.0):
        super().__init__(plane_type, spacing, offset)
        self.bounds = bounds

    def generate_points(self) -> np.ndarray:
        a_min, a_max, b_min, b_max = self.bounds
        a_points = np.arange(a_min, a_max, self.spacing)
        b_points = np.arange(b_min, b_max, self.spacing)

        if self.plane_type == 'x':
            points = [[self.offset, a, b] for a, b in product(a_points, b_points)]  # 使用offset
        elif self.plane_type == 'y':
            points = [[a, self.offset, b] for a, b in product(a_points, b_points)]
        else:  # 'z'
            points = [[a, b, self.offset] for a, b in product(a_points, b_points)]

        return np.array(points)

    def is_inside(self, point: np.ndarray) -> bool:
        x, y, z = point
        a_min, a_max, b_min, b_max = self.bounds

        if self.plane_type == 'x' and np.isclose(x, self.offset):  # 使用isclose处理浮点精度
            return (a_min <= y <= a_max) and (b_min <= z <= b_max)
        elif self.plane_type == 'y' and np.isclose(y, self.offset):
            return (a_min <= x <= a_max) and (b_min <= z <= b_max)
        elif self.plane_type == 'z' and np.isclose(z, self.offset):
            return (a_min <= x <= a_max) and (b_min <= y <= b_max)
        return False


#三角形
class TriangleZone(HazardZone):
    def generate_points(self) -> np.ndarray:
        a_min, b_min = np.min(self.vertices, axis=0)
        a_max, b_max = np.max(self.vertices, axis=0)

        a_points = np.arange(a_min, a_max, self.spacing)
        b_points = np.arange(b_min, b_max, self.spacing)

        points = []
        for a, b in product(a_points, b_points):
            if self.point_in_triangle((a, b)):
                if self.plane_type == 'x':
                    points.append([self.offset, a, b])  # 使用offset
                elif self.plane_type == 'y':
                    points.append([a, self.offset, b])
                else:  # 'z'
                    points.append([a, b, self.offset])

        return np.array(points)

    def is_inside(self, point: np.ndarray) -> bool:
        x, y, z = point
        if self.plane_type == 'x' and np.isclose(x, self.offset):
            return self.point_in_triangle((y, z))
        elif self.plane_type == 'y' and np.isclose(y, self.offset):
            return self.point_in_triangle((x, z))
        elif self.plane_type == 'z' and np.isclose(z, self.offset):
            return self.point_in_triangle((x, y))
        return False

#圆
class CircleZone(HazardZone):
    def generate_points(self) -> np.ndarray:
        a_center, b_center = self.center
        a_min, a_max = a_center - self.radius, a_center + self.radius
        b_min, b_max = b_center - self.radius, b_center + self.radius

        a_points = np.arange(a_min, a_max, self.spacing)
        b_points = np.arange(b_min, b_max, self.spacing)

        points = []
        for a, b in product(a_points, b_points):
            if (a - self.center[0]) ** 2 + (b - self.center[1]) ** 2 <= self.radius ** 2:
                if self.plane_type == 'x':
                    points.append([self.offset, a, b])  # 使用offset
                elif self.plane_type == 'y':
                    points.append([a, self.offset, b])
                else:  # 'z'
                    points.append([a, b, self.offset])

        return np.array(points)

    def is_inside(self, point: np.ndarray) -> bool:
        x, y, z = point
        if self.plane_type == 'x' and np.isclose(x, self.offset):
            return (y - self.center[0]) ** 2 + (z - self.center[1]) ** 2 <= self.radius ** 2
        elif self.plane_type == 'y' and np.isclose(y, self.offset):
            return (x - self.center[0]) ** 2 + (z - self.center[1]) ** 2 <= self.radius ** 2
        elif self.plane_type == 'z' and np.isclose(z, self.offset):
            return (x - self.center[0]) ** 2 + (y - self.center[1]) ** 2 <= self.radius ** 2
        return False

#半圆
import numpy as np
from itertools import product
from typing import Tuple

import numpy as np
from typing import Tuple

import numpy as np
from typing import Tuple

class SemicircleZone(HazardZone):
    def __init__(
        self,
        center: Tuple[float, float],  # 圆心坐标 (a, b)
        radius: float,                # 半径
        plane_type: str,              # 平面类型 ('x', 'y', 'z')
        spacing: float,               # 点间距
        offset: float = 0.0,          # 平面偏移量
    ):
        super().__init__(plane_type=plane_type, spacing=spacing, offset=offset)
        self.center = center
        self.radius = radius

    def generate_points(self) -> np.ndarray:
        a_center, b_center = self.center

        # 仅生成半圆弧上的点（θ ∈ [0, π]）
        theta = np.linspace(0, np.pi, int(np.pi * self.radius / self.spacing) + 1)
        arc = [
            (a_center + self.radius * np.cos(angle), b_center + self.radius * np.sin(angle))
            for angle in theta
        ]

        # 根据 plane_type 转换为 3D 坐标
        points = []
        for a, b in arc:
            if self.plane_type == 'x':
                points.append([self.offset, a, b])
            elif self.plane_type == 'y':
                points.append([a, self.offset, b])
            elif self.plane_type == 'z':
                points.append([a, b, self.offset])

        return np.array(points)

    def is_inside(self, point: np.ndarray) -> bool:
        x, y, z = point
        a_center, b_center = self.center

        if self.plane_type == 'x' and np.isclose(x, self.offset):
            dist_sq = (y - a_center)**2 + (z - b_center)**2
            return np.isclose(dist_sq, self.radius**2) and (z >= b_center)

        elif self.plane_type == 'y' and np.isclose(y, self.offset):
            dist_sq = (x - a_center)**2 + (z - b_center)**2
            return np.isclose(dist_sq, self.radius**2) and (z >= b_center)

        elif self.plane_type == 'z' and np.isclose(z, self.offset):
            dist_sq = (x - a_center)**2 + (y - b_center)**2
            return np.isclose(dist_sq, self.radius**2) and (y >= b_center)

        return False



def generate_viewpoints(
        normal_zones: List[HazardZone],
        danger_zones: List[HazardZone],
        normal_spacing: float,
        danger_spacing: float
) -> Tuple[np.ndarray, np.ndarray]:
    """
    生成视点（改进版：自动删除危险区域内的普通视点）
    Parameters:
        normal_zones: 普通区域列表
        danger_zones: 危险区域列表
        normal_spacing: 普通区域视点间距
        danger_spacing: 危险区域视点间距
    Returns:
        normal_points: 普通视点数组（已删除危险区域部分）
        danger_points: 危险视点数组（仅包含危险区域内新生成的点）
    """
    # 1. 先生成所有普通视点
    all_normal_points = []
    for zone in normal_zones:
        zone.spacing = normal_spacing
        all_normal_points.append(zone.generate_points())

    if not all_normal_points:
        raise ValueError("至少需要定义一个普通区域")

    all_normal_points = np.vstack(all_normal_points)

    # 2. 找到所有需要被删除的普通视点（位于危险区域内的）
    delete_mask = np.zeros(len(all_normal_points), dtype=bool)
    for i, point in enumerate(all_normal_points):
        for zone in danger_zones:
            if zone.is_inside(point):
                delete_mask[i] = True
                break

    # 3. 保留安全的普通视点
    normal_safe = all_normal_points[~delete_mask]

    # 4. 生成新的危险视点（原始危险区域内的点，但用更密的间距）
    danger_points = []
    for zone in danger_zones:
        # 先检查这个危险区域是否在某个普通区域内（否则不应该生成）
        in_normal_zone = False
        for n_zone in normal_zones:
            # 比较平面类型和偏移量是否相同
            if (n_zone.plane_type == zone.plane_type and
                    np.isclose(n_zone.offset, zone.offset)):
                in_normal_zone = True
                break

        if in_normal_zone:
            zone.spacing = danger_spacing
            danger_points.append(zone.generate_points())

    danger_points = np.vstack(danger_points) if danger_points else np.array([])

    return normal_safe, danger_points


# 可视化（修改可视化函数以显示多个平面）
def visualize_points(normal_points, danger_points):
    fig = plt.figure(figsize=(12, 9))
    ax = fig.add_subplot(111, projection='3d')

    # 绘制点
    if len(normal_points) > 0:
        ax.scatter(normal_points[:, 0], normal_points[:, 1], normal_points[:, 2],
                   c='blue', alpha=0.6, s=30, label='普通视点')
    if len(danger_points) > 0:
        ax.scatter(danger_points[:, 0], danger_points[:, 1], danger_points[:, 2],
                   c='red', alpha=0.8, s=50, label='危险视点')

    # 关闭 XYZ 轴等比例缩放（允许自由拉伸）
    ax.set_box_aspect(None)  # 关键修改：让 XYZ 轴独立缩放
    # 或者也可以使用：
    # ax.axis('auto')

    # 如果不希望自动调整轴范围，可以手动设置（例如这里假设 X/Y 较短，Z 较长）
    ax.set_xlim(0, 20)
    ax.set_ylim(0, 20)
    ax.set_zlim(0, 20 * 1.5)  # 让 Z 轴比 XY 轴长 1.5 倍

    # 绘制坐标平面（透明灰色平面）
#    xx, yy = np.meshgrid(np.linspace(0, 20, 2), np.linspace(0, 20, 2))
#    for z_offset in [0.0, 2.0]:  # 绘制两个 Z 平面
#        ax.plot_surface(xx, yy, np.full_like(xx, z_offset), alpha=0.1, color='gray')
#
#    # 绘制其他平面（X、Y）
#    ax.plot_surface(np.full_like(xx, 5.0), xx, yy, alpha=0.1, color='green')  # X=5
#    ax.plot_surface(xx, np.full_like(xx, -3.0), yy, alpha=0.1, color='blue')  # Y=-3

    ax.set_xlabel('X轴')
    ax.set_ylabel('Y轴')
    ax.set_zlabel('Z轴')
    ax.set_title('自由缩放的视点分布图')
    plt.legend()
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    # 普通区域（多个平面）
    normal_zones = [
        RectangleZone('z', (0, 15, 0, 50), 5.0, offset=15.0),  # Z=平面
        RectangleZone('x', (0, 50, 0, 15), 5.0, offset=0.0),  # X=平面
        RectangleZone('y', (0, 15, 0, 15), 5.0, offset=49.0),  # Y=平面

        RectangleZone('x', (0, 50, 0, 15), 5.0, offset=12.0),  # X=平面

        RectangleZone('x', (5, 15, -25, -3), 5.0, offset=0.0),  # X=平面
        RectangleZone('x', (32, 42, -25, -3), 5.0, offset=0.0),  # X=平面

        RectangleZone('x', (5, 15, -25, -3), 5.0, offset=12.0),  # X=平面
        RectangleZone('x', (5, 15, -25, -3), 5.0, offset=12.0),  # X=平面

        RectangleZone('x', (18, 29, -3, -0), 5.0, offset=12.0),  # X=平面
        RectangleZone('x', (18, 29, -3, 0), 5.0, offset=0.0),  # X=平面

        RectangleZone('y', (0, 15, -25, -3), 5.0, offset=5.0),  # Y=平面
        RectangleZone('y', (0, 15, -25, -3), 5.0, offset=42.0),  # Y=平面

        RectangleZone('y', (0, 15, -25, -15), 5.0, offset=15.0),  # Y=平面
        RectangleZone('y', (0, 15, -25, -15), 5.0, offset=32.0),  # Y=平面,

        # ✅ 修正后的 SemicircleZone，按用途调整圆心、半径和所在的平面
        SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=12.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        ),

        SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=9.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        ),

        SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=6.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        ),

        SemicircleZone(
            center=(23.5, -15.0),  # 圆心坐标（a, b）
            radius=8.0,  # 半径
            spacing=1.0,  # 点密度（可以调整）
            offset=3.0,  # 平面的偏移量（如果是 'x' 平面，offset 是 x 值）
            plane_type='x'  # 圆的所在平面（'x'/'y'/'z'）
        )
    ]

    # 危险区域（需要覆盖部分普通区域）
    danger_zones = [
        RectangleZone('z', (5, 10, 20, 25), 1.0, offset=15.0),   # 覆盖Z=0平面的部分区域 要注意，危险区域要在安全区域内奥
        #CircleZone('x', (10, 10), 4.0, 0.8, offset=5.0)        # 覆盖X=5平面的圆形区域
        RectangleZone('y', (5, 10, -25, -20), 5.0, offset=5.0),
        RectangleZone('y', (5, 10, -25, -20), 5.0, offset=42.0),

    ]

    # 生成视点（自动处理覆盖关系）
    normal_points, danger_points = generate_viewpoints(
        normal_zones=normal_zones,
        danger_zones=danger_zones,
        normal_spacing=3,
        danger_spacing=1.5
    )

    # 可视化（会发现危险区域内的普通点被自动删除）
    visualize_points(normal_points, danger_points)
