# 野生陆生海参
# EditTime:2025/4/23 10:33
import matplotlib.pyplot as plt
from typing import Dict, List
import numpy as np

def plot_convergence(fitness_history: List[float]):
    plt.figure(figsize=(10, 5))
    plt.plot(fitness_history, 'b-', linewidth=2)
    plt.title("Fitness Convergence")
    plt.xlabel("Generation")
    plt.ylabel("Best Fitness")
    plt.grid(True)
    plt.show()

# 可视化示例代理
def visualize_agent(
    agent_trajectories,
    normal_pts=None,  # 允许传入None
    danger_pts=None,
    show_points=False  # 默认关闭点显示
):
    try:
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D

        fig = plt.figure(figsize=(14, 10))
        ax = fig.add_subplot(111, projection='3d')

        # 固定比例和缩放
        ax.set_box_aspect([1, 1, 1])
        ax.set_autoscale_on(False)

        colors = ['red', 'green', 'blue']
        labels = ['UAV A', 'UAV B', 'UAV C']

        # --- 点集显示逻辑（默认不执行）---
        if show_points:
            if normal_pts is not None and len(normal_pts) > 0:
                ax.scatter(
                    normal_pts[:, 0], normal_pts[:, 1], normal_pts[:, 2],
                    c='gray', alpha=0.2, s=15, label='All Normal Points'
                )
            if danger_pts is not None and len(danger_pts) > 0:
                ax.scatter(
                    danger_pts[:, 0], danger_pts[:, 1], danger_pts[:, 2],
                    c='orange', alpha=0.3, s=20, label='All Danger Points'
                )

        # --- 始终绘制轨迹 ---
        for i, uav in enumerate(agent_trajectories):
            pts = uav['points']
            if len(pts) > 0:
                # 只显示轨迹路径（线条）
                ax.plot(
                    pts[:, 0], pts[:, 1], pts[:, 2],
                    color=colors[i], linestyle=':', alpha=0.6, linewidth=1.5,
                    label=labels[i]
                )
                # 可选：关闭轨迹点的散点
                # ax.scatter(pts[:, 0], pts[:, 1], pts[:, 2], color=colors[i], s=30)

        ax.set_xlabel('X轴')
        ax.set_ylabel('Y轴')
        ax.set_zlabel('Z轴')
        plt.title('无人机轨迹分配 (3架无人机)')
        plt.legend()
        plt.tight_layout()
        plt.show()

    except ImportError:
        print("Matplotlib未安装，跳过可视化")



# 可视化（修改可视化函数以显示多个平面）
def visualize_points(normal_points, danger_points):
    fig = plt.figure(figsize=(12, 9))
    ax = fig.add_subplot(111, projection='3d')

    # 绘制点
    if len(normal_points) > 0:
        ax.scatter(normal_points[:, 0], normal_points[:, 1], normal_points[:, 2],
                   c='blue', alpha=0.6, s=30, label='普通视点')
    if len(danger_points) > 0:
        ax.scatter(danger_points[:, 0], danger_points[:, 1], danger_points[:, 2],
                   c='red', alpha=0.8, s=50, label='危险视点')

    # 关闭 XYZ 轴等比例缩放（允许自由拉伸）
    ax.set_box_aspect(None)  # 关键修改：让 XYZ 轴独立缩放
    # 或者也可以使用：
    # ax.axis('auto')

    # 如果不希望自动调整轴范围，可以手动设置（例如这里假设 X/Y 较短，Z 较长）
    ax.set_xlim(0, 20)
    ax.set_ylim(0, 20)
    ax.set_zlim(0, 20 * 1.5)  # 让 Z 轴比 XY 轴长 1.5 倍

    # 绘制坐标平面（透明灰色平面）
#    xx, yy = np.meshgrid(np.linspace(0, 20, 2), np.linspace(0, 20, 2))
#    for z_offset in [0.0, 2.0]:  # 绘制两个 Z 平面
#        ax.plot_surface(xx, yy, np.full_like(xx, z_offset), alpha=0.1, color='gray')

#    # 绘制其他平面（X、Y）
#    ax.plot_surface(np.full_like(xx, 5.0), xx, yy, alpha=0.1, color='green')  # X=5
#    ax.plot_surface(xx, np.full_like(xx, -3.0), yy, alpha=0.1, color='blue')  # Y=-3

    ax.set_xlabel('X轴')
    ax.set_ylabel('Y轴')
    ax.set_zlabel('Z轴')
    ax.set_title('自由缩放的视点分布图')
    plt.legend()
    plt.tight_layout()
    plt.show()
